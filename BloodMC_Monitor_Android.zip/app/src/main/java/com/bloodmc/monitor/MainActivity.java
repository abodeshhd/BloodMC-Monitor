package com.bloodmc.monitor;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private LinearLayout list;
    private Button refresh;
    private final String[][] servers = {
        {"BloodMC Main", "134.255.255.67", "27064"},
        {"BloodMC Server 2", "134.255.255.67", "27222"},
        {"BloodMC Server 3", "134.255.255.67", "27060"},
        {"BloodMC Server 4", "134.255.255.66", "19214"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(120, 0, 0));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(12));
        root.setBackgroundColor(Color.rgb(17, 17, 17));

        TextView title = new TextView(this);
        title.setText("BloodMC Monitor");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("حالة سيرفرات Minecraft");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        refresh = new Button(this);
        refresh.setText("تحديث الحالة");
        root.addView(refresh);
        refresh.setOnClickListener(v -> loadServers());

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        loadServers();
    }

    private void loadServers() {
        refresh.setEnabled(false);
        refresh.setText("جارٍ الفحص...");
        list.removeAllViews();
        for (String[] server : servers) {
            TextView card = new TextView(this);
            card.setText(server[0] + "\n" + server[1] + ":" + server[2] + "\nجارٍ الاتصال...");
            card.setTextColor(Color.WHITE);
            card.setTextSize(16);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackgroundColor(Color.rgb(38, 38, 38));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(7), 0, dp(7));
            list.addView(card, lp);
            executor.execute(() -> {
                String result = checkServer(server[1], Integer.parseInt(server[2]));
                runOnUiThread(() -> {
                    card.setText(server[0] + "\n" + server[1] + ":" + server[2] + "\n" + result);
                    card.setTextColor(result.startsWith("متصل") ? Color.rgb(120, 230, 140) : Color.rgb(255, 120, 120));
                    boolean allDone = true;
                    for (int i = 0; i < list.getChildCount(); i++) {
                        if (((TextView) list.getChildAt(i)).getText().toString().contains("جارٍ الاتصال")) allDone = false;
                    }
                    if (allDone) {
                        refresh.setEnabled(true);
                        refresh.setText("تحديث الحالة");
                    }
                });
            });
        }
    }

    private String checkServer(String host, int port) {
        long start = System.currentTimeMillis();
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 4500);
            socket.setSoTimeout(4500);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            ByteArrayOutputStream handshake = new ByteArrayOutputStream();
            writeVarInt(handshake, 0);
            writeVarInt(handshake, 765);
            byte[] address = host.getBytes(StandardCharsets.UTF_8);
            writeVarInt(handshake, address.length);
            handshake.write(address);
            handshake.write((port >> 8) & 0xff);
            handshake.write(port & 0xff);
            writeVarInt(handshake, 1);
            ByteArrayOutputStream packet = new ByteArrayOutputStream();
            writeVarInt(packet, handshake.size());
            packet.write(handshake.toByteArray());
            out.write(packet.toByteArray());
            out.write(new byte[]{1, 0});
            out.flush();

            InputStream in = socket.getInputStream();
            int packetLength = readVarInt(in);
            int packetId = readVarInt(in);
            int jsonLength = readVarInt(in);
            if (packetLength < 1 || packetId != 0 || jsonLength < 1 || jsonLength > 100000) {
                return "متصل - تعذرت قراءة بيانات الحالة";
            }
            byte[] data = new byte[jsonLength];
            int offset = 0;
            while (offset < jsonLength) {
                int n = in.read(data, offset, jsonLength - offset);
                if (n < 0) throw new Exception("انقطع الاتصال");
                offset += n;
            }
            JSONObject json = new JSONObject(new String(data, StandardCharsets.UTF_8));
            String version = json.optJSONObject("version") != null ? json.getJSONObject("version").optString("name", "غير معروف") : "غير معروف";
            JSONObject players = json.optJSONObject("players");
            String count = players == null ? "?" : players.optInt("online", 0) + "/" + players.optInt("max", 0);
            long ping = System.currentTimeMillis() - start;
            return "متصل\nاللاعبون: " + count + "\nالإصدار: " + version + "\nPing: " + ping + " ms";
        } catch (Exception e) {
            return "غير متصل أو لا يستجيب";
        }
    }

    private static void writeVarInt(ByteArrayOutputStream out, int value) {
        while ((value & -128) != 0) {
            out.write((value & 127) | 128);
            value >>>= 7;
        }
        out.write(value);
    }

    private static int readVarInt(InputStream in) throws Exception {
        int numRead = 0, result = 0, read;
        do {
            read = in.read();
            if (read == -1) throw new Exception("EOF");
            result |= (read & 0x7f) << (7 * numRead);
            numRead++;
            if (numRead > 5) throw new Exception("VarInt too big");
        } while ((read & 0x80) != 0);
        return result;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
